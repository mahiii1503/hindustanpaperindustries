window.addEventListener('scroll', () => {
  const nav = document.querySelector('.navbar');
  if (window.scrollY > 50) {
    nav.style.backgroundColor = '#000';
  } else {
    nav.style.backgroundColor = '#222';
  }
});